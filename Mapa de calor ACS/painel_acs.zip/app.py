
import streamlit as st
import pandas as pd
import folium
from folium.plugins import HeatMap
from streamlit_folium import st_folium
import plotly.express as px
from datetime import timedelta

st.set_page_config(page_title="Painel de Visitas - ACS", layout="wide")
st.title("📍 Monitoramento das Visitas dos ACS")

@st.cache_data
def carregar_dados():
    return pd.read_csv("data/visitas_acs.csv", parse_dates=["data_visita"])

df = carregar_dados()

st.sidebar.header("Filtros")
acs_opcao = st.sidebar.multiselect("Selecione ACS", df["ACS"].unique(), default=df["ACS"].unique())
ubs_opcao = st.sidebar.multiselect("Selecione UBS", df["UBS"].unique(), default=df["UBS"].unique())
dias = st.sidebar.slider("Últimos X dias", 1, 30, 7)

df_filtrado = df[
    (df["ACS"].isin(acs_opcao)) &
    (df["UBS"].isin(ubs_opcao)) &
    (df["data_visita"] >= (df["data_visita"].max() - timedelta(days=dias)))
]

col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("Mapa de Calor das Visitas")
    mapa = folium.Map(location=[-15.80, -47.90], zoom_start=11)
    HeatMap(df_filtrado[['latitude', 'longitude']].values.tolist(), radius=12).add_to(mapa)
    st_folium(mapa, width=800, height=500)

with col2:
    st.subheader("Visitas por Dia")
    visitas_dia = df_filtrado.groupby('data_visita').size().reset_index(name='visitas')
    fig = px.line(visitas_dia, x='data_visita', y='visitas', markers=True, title="Série Temporal")
    st.plotly_chart(fig, use_container_width=True)

st.markdown("### ⚠️ Alertas Inteligentes")
st.write("Áreas sem visita nos últimos 30 dias (simulado):")
st.markdown("- Região Norte de Samambaia")
st.markdown("- Setor Habitacional Sol Nascente Trecho 3")
